# ***HOUSE OF POSH – HTML TEMPLATE***



Thank you for purchasing the House of Posh HTML Website Template.

This package includes all files required to run, customize, and publish the website.





# **📁 FILE STRUCTURE**



All files are contained in one folder:



House-of-Posh/

│── index.html

│── about.html

│── services.html

│── perfumes.html

│── bookings.html

│── gallery.html

│── contact.html

│── style.css

│── script.js

│── (all images)

│── README.txt

│── LICENSE.txt





✔ No additional installs required

✔ No frameworks required

✔ 100% standalone HTML, CSS, and JavaScript







### ✨ FEATURES



Fully responsive design



Mobile hamburger menu



Smooth fade-in animations



Lightbox gallery (where applicable)



Booking, services, gallery, and about sections



Elegant modern branding



Editable colors \& content



Google Fonts included (no download needed)







# 🎨 CUSTOMIZATION



Colors, fonts, spacing



Go to style.css and adjust variables or specific selectors as needed.



Images



Replace any .jpg or .png with your own images.

Make sure filenames match your HTML references.



Text



Open any HTML file and edit content inside containers.



Logo



Replace:



houseof posh logo.png





with your own logo (same filename recommended).







# 📱 MOBILE MENU



The responsive hamburger toggle is handled in:



script.js





No additional libraries are required.





# 🌐 GOOGLE FONTS USED



These are loaded automatically — nothing to download:



Poppins



Great Vibes







# 🚀 DEPLOYMENT



Upload all files together to your hosting provider:



Popular options:



Netlify



Hostinger



GoDaddy



Namecheap



cPanel hosting



GitHub Pages



Make sure the folder structure remains intact.



📩 SUPPORT



If you need help customizing the template, you can contact the seller or designer who provided the package.

Khaya Mckinon Mkhumane

WhatsApp: +2772449092

khayacomply@gmail.com

